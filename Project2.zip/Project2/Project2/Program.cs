﻿namespace Project2
{
    internal class Program
    {
        static List<Class2> adatok;

        static void Fajlbeolvasasa(string FajlNev)
        {
            adatok = new List<Class2>();
            foreach (var sor in File.ReadAllLines(FajlNev).Skip(1))
            {
                var SorElemei = sor.Split(' ');
                string t = (SorElemei[0]);
                byte n = byte.Parse(SorElemei[1]);
                byte tu = byte.Parse(SorElemei[2]);
                byte ar = byte.Parse(SorElemei[3]);

                adatok.Add(new Class2(t,n,tu,ar));
            }

        }

        static void Main(string[] args)
        {
            
        }

    }
}