﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    internal class Class2
    {
        string tipus;
        byte nev;
        byte tulj;
        byte ar;

    }
    public Class2(){}

    public Class2(string tipus, byte nev, byte tulj, byte ar)
    {
        this.tipus = tipus;
        this.nev = nev;
        this.tulj = tulj;
        this.ar = ar;
    }


}
