﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt2
{
    internal class Feladat
    {
        List<Alkatreszek> adatok = new List<Alkatreszek>();
        List<string> lista = new List<string>();
        
        public void Beir()
        {
            int tab = 0;
            Console.WriteLine("Elég adatot írt be? (I vagy N)");
            string eleg = Console.ReadLine() ?? "";
            do
            {
                Console.WriteLine("Adja meg az alkatrész típusát: ");
                string tipus = Console.ReadLine() ?? "";
                lista.Add(tipus);
                Console.WriteLine("Adja meg az alkatrész nevét: ");
                string nev = Console.ReadLine() ?? "";
                lista.Add(nev);
                Console.WriteLine("Adja meg az alkatrész paraméterét: ");
                string paramet = Console.ReadLine() ?? "";
                lista.Add(paramet);
                Console.WriteLine("Adja meg az alkatrész árát: ");
                int ar = Convert.ToInt32(Console.ReadLine() ?? "");
                lista.Add(Convert.ToString(ar));
                StreamWriter sw = new StreamWriter("alkatresz.txt");
                foreach (var item in lista)
                {
                    sw.Write(item +";") ;
                    tab++;
                    if(tab ==5)
                    {
                        sw.WriteLine(item+";");
                        tab = 0;
                    }
                }
                sw.Close();
                Console.WriteLine("Elég adatot írt be? (I vagy N)");
                 eleg = Console.ReadLine() ?? "";

            } while (eleg!="I");
        }
    }
}
