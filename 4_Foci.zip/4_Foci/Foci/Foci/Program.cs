﻿using System.Security.Cryptography.X509Certificates;

namespace Foci
{
    internal class Program
    {
        static List<Class1> meccsek;

        static void Fajlbeolvasasa(string FajlNev)
        {
            meccsek= new List<Class1>();
            foreach(var sor in File.ReadAllLines(FajlNev).Skip(1))
            {
                var SorElemei = sor.Split(' ');
                byte f = byte.Parse(SorElemei[0]);
                byte hv= byte.Parse(SorElemei[1]);
                byte vv= byte.Parse(SorElemei[2]);
                byte hf= byte.Parse(SorElemei[3]);
                byte vf= byte.Parse(SorElemei[4]);
                string hcs = (SorElemei[5]);
                string vcs =(SorElemei[6]);
                meccsek.Add(new Class1(f, hv, vv, hf, vf, hcs, vcs));
            }

        }

        static void Main(string[] args)
        {
            Fajlbeolvasasa("meccs.txt");
            Console.WriteLine(meccsek.Count());
            Console.Write("Add meg egy forduló sorszámát: ");
            byte beFordulo = byte.Parse(Console.ReadLine());
            Console.WriteLine($" 2. feladat: A(z) {beFordulo}. forduló meccsei:");
            foreach(var m in meccsek)
            {
                if (m.Fordulo == beFordulo)
                    Console.WriteLine(m.MeccsEredmeny());
            }
            /*var xFMeccsei = meccsek.Where(x => x.Fordulo == beFordulo);*/

            //3.Feladat
            Console.WriteLine("3. feladat");
            foreach(var m in meccsek)
            {
                if (m.VoltForditas())
                    Console.WriteLine($"{m.Fordulo}: {m.GyoztesCsapat()}");
            }
            //4. feladat
            Console.WriteLine("4. feladat: Add meg egy csapat nevét");
            string beCsapat = Console.ReadLine();

            //5 feladat
            Console.WriteLine($"5. feladat: lőtt gólok: {LottGolokSzama(beCsapat)}, kapott gólok: {KapottGolokSzama(beCsapat)}");

            //6. feladat
            List<Class1> otthonKikapott = new List<Class1>();
            foreach( var m in meccsek)
            {
                if (m.HazaiCsapat == beCsapat && m.VesztesCsapat() == beCsapat)
                    otthonKikapott.Add(m);
            }
            if (otthonKikapott.Count == 0)
                Console.WriteLine("6. feladat: Nem kapott ki otthon");
            else
            {
                Class1 eloszor = otthonKikapott[0];
                foreach(var m in otthonKikapott)
                {
                    if(m.Fordulo < eloszor.Fordulo)
                    {
                        eloszor = m;
                    }
                }
                Console.WriteLine($"6. feladat:  {eloszor.Fordulo}. forduló, {eloszor.GyoztesCsapat()}");
            }
            Console.ReadKey();
            
        }
        static byte LottGolokSzama(string csapatNev)
        {
            byte lottGolok = 0;
            foreach(var m in meccsek)
            {
                if (m.HazaiCsapat == csapatNev)
                    lottGolok += m.HazaiVeg;
                else if (m.VendegCsapat == csapatNev)
                    lottGolok += m.VendegVeg;
            }
            return lottGolok;
        }
        static byte KapottGolokSzama(string csapatNev)
        {
            byte kapottGolok = 0;
            foreach (var m in meccsek)
            {
                if (m.HazaiCsapat == csapatNev)
                    kapottGolok += m.VendegVeg;
                else if (m.VendegCsapat == csapatNev)
                    kapottGolok += m.HazaiVeg;
            }
            return kapottGolok;
        }
    }
}