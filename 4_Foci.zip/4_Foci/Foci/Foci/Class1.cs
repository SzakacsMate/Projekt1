﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Foci
{
    internal class Class1
    {
        byte fordulo;
        byte hazaiVeg;
        byte vendegVeg;
        byte hazaiFelido;
        byte vendegFelido;
        string hazaiCsapat;
        string vendegCsapat;

        public Class1(){}

        public Class1(byte fordulo,byte hazaiVeg,byte vendegVeg,byte hazaiFelido, byte vendegFelido, string hazaiCsapat, string vendegCsapat)
        {
            this.fordulo = fordulo;
            this.hazaiVeg = hazaiVeg;
            this.vendegVeg = vendegVeg;
            this.hazaiFelido = hazaiFelido;
            this.vendegFelido = vendegFelido;
            this.hazaiCsapat = hazaiCsapat;
            this.vendegCsapat = vendegCsapat;

        }

        public byte Fordulo { get => fordulo; }
        public string HazaiCsapat { get => hazaiCsapat;  }
        public string VendegCsapat { get => vendegCsapat;  }
        public byte HazaiVeg { get => hazaiVeg; }
        public byte VendegVeg { get => vendegVeg; }

        public string MeccsEredmeny()
        {
            return $"{hazaiCsapat}-{vendegCsapat}: {hazaiVeg}-{vendegVeg} ({hazaiFelido}-{vendegFelido})";
        }

        public string GyoztesCsapat()
        {
            if (hazaiVeg > vendegVeg)
                return hazaiCsapat;
            else if (hazaiVeg < vendegVeg)
                return vendegCsapat;
            else return " Döntetlen";
        }

        public string VesztesCsapat()
        {
            if (hazaiVeg > vendegVeg)
                return vendegCsapat;
            else if (hazaiVeg < vendegVeg)
                return hazaiCsapat;
            else return " Döntetlen";
        }

        public bool VoltForditas()
        {
            if((hazaiFelido > vendegFelido && hazaiVeg < vendegVeg)||(hazaiFelido < vendegFelido && hazaiVeg > vendegVeg))
                return true;
            return false;
        }

    }
}
