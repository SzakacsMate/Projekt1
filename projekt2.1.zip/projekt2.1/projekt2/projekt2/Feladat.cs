﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt2
{
    internal class Feladat
    {
        List<Alkatreszek> adatok = new List<Alkatreszek>();
        List<string> lista = new List<string>();
        
        public void Beir()
        {
            Console.WriteLine("Akar-e adatot bevinni? I/N");
            string dontes = Console.ReadLine() ?? "";
            if (dontes == "I")
            {
                string eleg = "";
                do
                {
                    Console.WriteLine("Adja meg az alkatrész típusát: ");
                    string tipus = Console.ReadLine() ?? "";
                    lista.Add(tipus + ";");
                    Console.WriteLine("Adja meg az alkatrész nevét: ");
                    string nev = Console.ReadLine() ?? "";
                    lista.Add(nev + ";");
                    Console.WriteLine("Adja meg az alkatrész paraméterét: ");
                    string paramet = Console.ReadLine() ?? "";
                    lista.Add(paramet + ";");
                    Console.WriteLine("Adja meg az alkatrész árát: ");
                    int ar = Convert.ToInt32(Console.ReadLine() ?? "");
                    lista.Add(Convert.ToString(ar + "\n"));
                    StreamWriter sw = new StreamWriter("alkatresz.txt");
                    foreach (var item in lista)
                    {
                        sw.Write(item);
                    }
                    sw.Close();
                    Console.WriteLine("Elég adatot írt be? (I vagy N)");
                    eleg = Console.ReadLine() ?? "";

                } while (eleg.ToUpper() != "I");
            }
        }
        public void Beolvasas()
        {
            foreach (var item in File.ReadAllLines("alkatresz.txt", Encoding.UTF8))
            {
                string[] resz = item.Split(';');
                string tipus = resz[0];
                string nev = resz[1];
                string parameter = resz[2];
                int ar =Convert.ToInt32(resz[3]);
                Alkatreszek ujAlkatreszek = new Alkatreszek(tipus, nev, parameter, ar);
                adatok.Add(ujAlkatreszek);
            }
        }
        public void Kereses()
        {
            Console.WriteLine("Mire szeretne rákeresni?");
            Console.WriteLine("Alkatrész típusára (T)");
            Console.WriteLine("Alkatrész nevére (N)");
            Console.WriteLine("Alkatrész árára(C)");
            string keresett = Console.ReadLine() ??"";
            if (keresett.ToUpper()=="T")
            {
                Console.Write("Írja be az alkatrész típusát: ");
                string type= Console.ReadLine()??"";
                foreach (var item in adatok)
                {
                    if (item.Tipus==type)
                    {
                        Console.WriteLine($"A keresett típusú alkatrész adatai: {item.Tipus},{item.Nev},{item.Parameter},{item.Ar}");
                    }
                    else
                    {
                        Console.WriteLine("Nincs találat");
                    }
                }
            }
            else if (keresett.ToUpper() == "N")
            {
                Console.Write("Írja be az alkatrész nevét: ");
                string name = Console.ReadLine() ?? "";
                foreach (var item in adatok)
                {
                    if (item.Nev == name)
                    {
                        Console.WriteLine($"A keresett típusú alkatrész adatai: {item.Tipus},{item.Nev},{item.Parameter},{item.Ar}");
                    }
                    else
                    {
                        Console.WriteLine("Nincs találat");
                    }    
                }
            }
            else if (keresett.ToUpper()=="C")
            {
                Console.Write("Adja meg az ár alsó határát: ");
               int alsoar= Convert.ToInt32(Console.ReadLine() ?? "");
                Console.Write("Adja meg az ár felső határát: ");
                int felsoar = Convert.ToInt32(Console.ReadLine() ?? "");
                foreach (var item in adatok)
                {
                    if(item.Ar>=alsoar && item.Ar<=felsoar)
                    {
                        Console.WriteLine($"A két ár közötti alkatrészek adatai: {item.Tipus},{item.Nev},{item.Parameter},{item.Ar}");
                    }
                }

            }

            
        }
        public void Statisztika()
        {
            int proci = 0;
            int monitor = 0;
            int egyeb = 0;
            foreach (var item in adatok)
            {
                if (item.Tipus.ToLower()=="monitor")
                {
                    monitor++;
                }
                else if (item.Tipus.ToLower() == "cpu")
                {
                    proci++;
                }
                else
                {
                    egyeb++;
                }

            }

        }

        public void Learazas()
        {

            Random r = new();
            StreamWriter sw = new StreamWriter("alkatreszek2.txt");
            int valasztott = r.Next(1, 9);
            if(valasztott==1)
                {
                    foreach (var item in adatok)
                    {
                        if(item.Tipus.ToLower()=="alaplap")
                        {
                        sw.WriteLine($"{item.Tipus} {item.Nev} {item.Parameter} {item.Ar*(r.Next(50,99) / 100)}");
                    }
                    }
                }
                /*
                if (item.Versenyszam == "kajakkenu")
                    sw.WriteLine($"{item.Helyezes} {item.SportolokSzama} {item.Pontszam} kajak-kenu {item.Versenyszam}");
                else
                    sw.WriteLine($"{item.Helyezes} {item.SportolokSzama} {item.Pontszam} {item.Sportag} {item.Versenyszam}");
                 */
               

            sw.Close();
        }

    }
}
