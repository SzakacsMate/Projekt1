﻿namespace projekt2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Feladat f = new Feladat();
            f.Beir();
            f.Beolvasas();
            f.Kereses();
        }
    }
}

