let arak = []

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function general() {
    document.getElementById("akcioGomb").disabled=false;
    let arDb = Number(document.getElementById("arDb").value)
    document.getElementById("kiiras").innerHTML = "";
    for (let i = 0; i < arDb; i++) {
        arak.push(getRndInteger(100, 20000))
        document.getElementById("kiiras").innerHTML += `<div class="col-6 col-md-4 col-lg-2">${arak[i]} Ft</div>`;
    }
}


function Akcio() {
    let hatar = document.getElementById("hatar").value;
    let akcio = document.getElementById("akcio").value;
    document.getElementById("kiiras").innerHTML="";
    for (let i = 0; i < arak.length; i++) {
        if (arak[i] > hatar) {
            arak[i] -=  arak[i] * (akcio / 100)
            document.getElementById("kiiras").innerHTML += `<div class="col-6 col-md-4 col-lg-2 akcios">${arak[i]} Ft</div>`;
        }
        else {
            document.getElementById("kiiras").innerHTML += `<div class="col-6 col-md-4 col-lg-2">${arak[i]} Ft</div>`;
        }

    }
    document.getElementById("akcioGomb").disabled=true;
}