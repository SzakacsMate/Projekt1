let termekek=["Alma","Kenyér","Tej","Szőlő","Pisztácia","Barack"]
let ertekelesek=[0,0,0,0,0,0]
let aktualis=-1;

for (let i=0; i<termekek.length;i++)
{
    document.getElementById("menu").innerHTML+=`<li><button class="dropdown-item" type="button" onclick="Valasztas(${i})">${termekek[i]}</button></li>`
}

Valasztas(0)

function Valasztas(x) {
    aktualis=x;
    document.getElementById("kiiras").innerHTML=`<h1>${termekek[x]}</h1>`
    if (ertekelesek[x]!=0)
    {
        CsillagKiir(ertekelesek[aktualis])
    }
    else
    {
        document.getElementById("csillag").innerHTML="Még nincs értékelve!"
    }
}

function Ertekeles() {
    y = Number(document.getElementById("star").value)
    CsillagKiir(y)
    ertekelesek[aktualis]=y;
}

function CsillagKiir(x)
{
    document.getElementById("csillag").innerHTML=""
    z = '<img src="star.png">'
    for (let i=0;i<x;i++)
    {
        document.getElementById("csillag").innerHTML += z
    }
}